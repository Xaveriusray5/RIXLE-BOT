module.exports = { 
name: "antitoxic",  
async functions(m) { 
let { conn, text } = data
//let badwordRegex = /anjing/

//let name = conn.getName(m.sender)
//if (m.isBaileys && m.fromMe) return  !0
//let isBadword = badwordRegex.exec(m.text)

//if (!isBadword) {
//m.reply( name + 'Terdeteksi Menggunakan bahasa kotor, Kami hanya memberi mu warn\n@0')
//}
//return !0
}
}
