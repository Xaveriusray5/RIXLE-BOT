<p align="center">
	<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrF6fyFoGCHmsmOXWjFxIXh-467D1nRhA4mQ&usqp=CAU" width="75%" style="margin-left: auto;margin-right: auto;display: block;">
</p>
<p align="center">
<a href="#"><img title="RIXLE - BOT" src="https://img.shields.io/badge/RixleBot-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/Rizxyu"><img title="Fauzan" src="https://img.shields.io/badge/Author-Fauzan-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
</p>
</div>

# Join Group
[![Group Bot](https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/JFqb84LyIhfJJxFsKc3apI)

# ONLY RUN RAILWAY
[`railway.app`](https://railway.app/new/github)
## REST API
**[`Riz Api`](https://rizapi.herokuapp.com/)**

## ✍️ Editing the file

Edit the required value in [`config.js`](https://github.com/Rizxyu/RIXLE-BOT/blob/main/config.js)

Create a new account at [`monggodb`](https://www.mongodb.com/cloud/atlas/register)

```js
userbot = {
 owner: [
  "6281261324817",
  "62822980698995", 
  "436504463151666",
  "6282328303332",
  "62823283033323"
  ],
  MONGO_URI: "mongodb+srv://<username>:<password>@cluster0.eyx0e.mongodb.net/<dbname>?retryWrites=true&w=majority",
  mess: {
   wait: "tunggu sedang di proses...",
   error: "errorr!!"
   },
   prefix: ["/"],
   gexp: 50,
   packname: "RIXLE-BOT OFFICIAL",
   author: '@_FearTeam',

    setting: {
    admin: "only admin",
    group: "only group",
    owner: "owner only pack",
    jadibot: "jadibot only",
    botadmin: "bot harus menjadi admin"
    }
}
```

# KHUSUS TERMUX↓
[`githubdl`](https://github.com/Fau-Zan/Rixle-botV2)

# RDP/VPS/LINUX


## FEATURE LIST 💡

| FEATURE |🌱|
| ------------- | ------------- |
| Anti Toxic|✅|
| Anti Troli|✅|
| Anti Virtex|✅|
| Anti Link Group|✅|
| Anonymous Chat|✅|

| GRUP |👥|
| ------------- | ------------- |
| Join|✅|
| add|✅|
| open gc|✅|
| Close gc|✅|
| absen|✅|

| download |🎵|
| ------------- | ------------- |
| play|✅|
| yta|✅|
| ytv|✅|
| tiktok |✅|

| islami |🕌|
| ------------- | ------------- |
| Surah <ayat> | ✅|

| OTHER |🤗|
| ------------- | ------------- |
| Jadibot|✅|
| Wikipedia|✅|
| Google search|✅|
| Sticker|✅|

# [`👥My Team`](https://chat.whatsapp.com/D75oLHFNUXQCenRThcKUD1)
* [`Fauzan (Dev)`](https://github.com/Fau-Zan)
* [`Ivan (Dev)`](https://github.com/ivan-MLN)
* [`Sanz (Dev)`](https://github.com/sanzgantengz)
* [`Rizky (Dev)`](https://github.com/Rizxyu)
* [`Arifi Razzaq (Dev)`](https://github.com/Arifirazzaq2001)
* [`O r e k i (Contributor)`](https://github.com/Oreki-san)
* [`ＲｉｘｌｅＢoｔ (Robot)`](https://wa.me/62823283033323)
